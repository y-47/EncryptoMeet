const localVideo = document.getElementById('local-video');
const remoteVideo = document.getElementById('remote-video');
const startButton = document.getElementById('start-button');
const hangUpButton = document.getElementById('hang-up');
const toggleVideoButton = document.getElementById('toggle-video');
const toggleAudioButton = document.getElementById('togglea-udio');
const shareMeetingInfoButton = document.getElementById('share-meeting-id');

let localStream;
let peerConnection;

const configuration = {
    iceServers: [
        {
            urls: 'stun:stun.l.google.com:19302',
        },
    ],
};

async function startCall() {
    try {
        localStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
        localVideo.srcObject = localStream;

        peerConnection = new RTCPeerConnection(configuration);

        localStream.getTracks().forEach((track) => {
            peerConnection.addTrack(track, localStream);
        });

        peerConnection.ontrack = (event) => {
            remoteVideo.srcObject = event.streams[0];
        };

        const offer = await peerConnection.createOffer();
        await peerConnection.setLocalDescription(offer);

        // In a real application, send the offer to the other participant using your signaling server
        console.log('Offer:', peerConnection.localDescription);

    } catch (error) {
        console.error(error);
    }
}

hangUpButton.addEventListener('click', async () => {
    if (peerConnection) {
        peerConnection.close();
        peerConnection = null;

        localStream.getTracks().forEach((track) => {
            track.stop();
        });
    }
});

// video on/off feature
let isVideoOn = false; // Initially video is off

async function toggleVideo() {
    const videoButton = document.getElementById('toggle-video');
    const localVideo = document.getElementById('local-video');

    try {
        if (!isVideoOn) {
            const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
            localVideo.srcObject = stream;
            isVideoOn = true;
        } else {
            const stream = localVideo.srcObject;
            const tracks = stream.getTracks();
            tracks.forEach(track => track.stop());
            localVideo.srcObject = null;
            isVideoOn = false;
        }

        const videoIcon = isVideoOn ? 'Camera On' : 'Camera Off 🚫 '; // Change icons based on video state
        videoButton.innerHTML = videoIcon; // Update button text with the correct icon
    } catch (error) {
        console.error('Error accessing camera:', error);
        // Handle error (e.g., show error message to the user)
    }
}

let isAudioOn = false; // Initially audio is off

async function toggleAudio() {
    const audioButton = document.getElementById('toggle-audio');
    const localVideo = document.getElementById('local-video');

    try {
        if (!isAudioOn) {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const videoStream = localVideo.srcObject;
            if (videoStream) {
                // Merge the audio stream with the existing video stream
                const audioTrack = stream.getAudioTracks()[0];
                videoStream.addTrack(audioTrack);
                localVideo.srcObject = videoStream;
            } else {
                // Set the audio stream as the srcObject if no video stream exists
                localVideo.srcObject = stream;
            }
            isAudioOn = true;
        } else {
            const stream = localVideo.srcObject;
            const audioTracks = stream.getAudioTracks();
            audioTracks.forEach(track => track.stop());
            if (stream.getVideoTracks().length === 0) {
                // Clear srcObject if no video tracks are present
                localVideo.srcObject = null;
            }
            isAudioOn = false;
        }

        const audioIcon = isAudioOn ? 'Audio On 🔊' : 'Audio Off 🔇'; // Change icons based on audio state
        audioButton.innerHTML = audioIcon; // Update button text with the correct icon
    } catch (error) {
        console.error('Error accessing microphone:', error);
        // Handle error (e.g., show error message to the user)
    }
}




// Function to share meeting info
function shareMeetingInfo() {
    const meetingId = generateMeetingID(); // Generate a meeting ID (you can replace this with your actual meeting ID generation logic)
    const meetingPassword = generateMeetingPassword(); // Generate a meeting password (you can replace this with your actual meeting password generation logic)

    // Example of sharing via alert, you can use other methods like copying to clipboard, etc.
    alert(`Meeting ID: ${meetingId}\nPassword: ${meetingPassword}`);
}

// Generate a random string of given length (you can replace this with your actual meeting ID generation logic)
function generateMeetingID() {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 8; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
}

// Generate a random string of given length (you can replace this with your actual meeting password generation logic)
function generateMeetingPassword() {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
}

// Attach the shareMeetingInfo function to the button's click event listener
shareMeetingInfoButton.addEventListener('click', shareMeetingInfo);

